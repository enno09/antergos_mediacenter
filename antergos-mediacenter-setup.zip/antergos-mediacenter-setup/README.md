Default Antergos openbox configuration

- http://www.antergos.com
- http://www.openbox.org

Includes setup for:

- compton
- conky
- gtk2
- gtk3
- oblogout
- openbox
- tint2
- volumeicon
- xorg-xinit
